import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addsalesreturn',
  templateUrl: './addsalesreturn.component.html',
  styleUrls: ['./addsalesreturn.component.scss']
})
export class AddsalesreturnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
