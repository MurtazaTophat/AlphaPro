import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editsalereturn',
  templateUrl: './editsalereturn.component.html',
  styleUrls: ['./editsalereturn.component.scss']
})
export class EditsalereturnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
