import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editcategory',
  templateUrl: './editcategory.component.html',
  styleUrls: ['./editcategory.component.scss']
})
export class EditcategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
