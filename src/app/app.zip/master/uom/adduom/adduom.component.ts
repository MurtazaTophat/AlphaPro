import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adduom',
  templateUrl: './adduom.component.html',
  styleUrls: ['./adduom.component.scss']
})
export class AdduomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
