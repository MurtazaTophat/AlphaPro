import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edituom',
  templateUrl: './edituom.component.html',
  styleUrls: ['./edituom.component.scss']
})
export class EdituomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
