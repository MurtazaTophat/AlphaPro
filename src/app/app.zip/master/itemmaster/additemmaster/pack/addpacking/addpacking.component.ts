import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addpacking',
  templateUrl: './addpacking.component.html',
  styleUrls: ['./addpacking.component.scss']
})
export class AddpackingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
