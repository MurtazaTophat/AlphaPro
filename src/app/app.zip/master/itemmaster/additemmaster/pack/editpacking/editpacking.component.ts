import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editpacking',
  templateUrl: './editpacking.component.html',
  styleUrls: ['./editpacking.component.scss']
})
export class EditpackingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
