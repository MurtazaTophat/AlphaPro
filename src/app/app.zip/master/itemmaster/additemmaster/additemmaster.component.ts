import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-additemmaster',
  templateUrl: './additemmaster.component.html',
  styleUrls: ['./additemmaster.component.scss']
})
export class AdditemmasterComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }

}
