import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addbrand',
  templateUrl: './addbrand.component.html',
  styleUrls: ['./addbrand.component.scss']
})
export class AddbrandComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
