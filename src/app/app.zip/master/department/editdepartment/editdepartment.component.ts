import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editdepartment',
  templateUrl: './editdepartment.component.html',
  styleUrls: ['./editdepartment.component.scss']
})
export class EditdepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
