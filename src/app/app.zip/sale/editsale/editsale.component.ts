import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editsale',
  templateUrl: './editsale.component.html',
  styleUrls: ['./editsale.component.scss']
})
export class EditsaleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
