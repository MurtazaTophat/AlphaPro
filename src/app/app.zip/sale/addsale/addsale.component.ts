import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addsale',
  templateUrl: './addsale.component.html',
  styleUrls: ['./addsale.component.scss']
})
export class AddsaleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
