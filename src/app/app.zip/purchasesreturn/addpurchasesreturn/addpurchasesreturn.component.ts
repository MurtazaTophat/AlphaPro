import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addpurchasesreturn',
  templateUrl: './addpurchasesreturn.component.html',
  styleUrls: ['./addpurchasesreturn.component.scss']
})
export class AddpurchasesreturnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
