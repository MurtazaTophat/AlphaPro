import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editpurchasesreturn',
  templateUrl: './editpurchasesreturn.component.html',
  styleUrls: ['./editpurchasesreturn.component.scss']
})
export class EditpurchasesreturnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
