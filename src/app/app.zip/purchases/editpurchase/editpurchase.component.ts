import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editpurchase',
  templateUrl: './editpurchase.component.html',
  styleUrls: ['./editpurchase.component.scss']
})
export class EditpurchaseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
