import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addpurchase',
  templateUrl: './addpurchase.component.html',
  styleUrls: ['./addpurchase.component.scss']
})
export class AddpurchaseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
