import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchaseledgers',
  templateUrl: './purchaseledgers.component.html',
  styleUrls: ['./purchaseledgers.component.scss']
})
export class PurchaseledgersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
